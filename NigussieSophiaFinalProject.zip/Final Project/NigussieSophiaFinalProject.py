import tkinter
from tkinter import ttk
from tkinter import *
#from images import Image
from PIL import ImageTk, Image
from tkinter import messagebox

root = tkinter.Tk()



root.title("Sunshine Pizza")
root.geometry("800x600")

label1 = Label(root, text = "Welcome  \n Sunshine Pizza", font=('Calibri', 35, 'bold'))
label1.pack()


label1 = Label(root, text = "Please click below to otder Pizza", font=('Times New Roman', 10, 'bold'))
label1.pack()


def ask_yesornoQ():
    answer=messagebox.askquestion('Title','Do you want to Exit?')
    #print(answer)
    if answer.lower()=="yes":
        root.destroy()
            
    
##################################################################################################################
def OrderingForm():
    window = tkinter.Toplevel()
    PIZZA = ["","Cheese Pizza","Veggie Pizza","Pesto Pizza","Deep Dish Pizza","Chicken Wings","Bread Stick"] #etc
    WingBread = ["","Chicken Wings","Bread Stick"]
    PIZZASIZE= ["","Small","Medium","Large","Extra Large"]
    PIZZATopping= ["","Beff","Chicken","Olives","Pepers"]

    global count
    global counter
    global Pizzaadd
    global Pizzasizeadd
    global Pizzaqntadd
    global Pizzatoppingadd
    global del_buttons


    def PriceCal(pizza,psize):
            Pizzatype=["Cheese Pizza","Veggie Pizza","Pesto Pizza","Deep Dish Pizza","Chicken Wings","Bread Stick"]
            SelPizzaSize=["Small","Medium","Large","Extra Large"]
            if pizza in Pizzatype:
                if pizza==Pizzatype[0]:
                    if psize==SelPizzaSize[0]:
                        price=8.99
                    elif psize==SelPizzaSize[1]:
                        price=10.99
                    elif psize==SelPizzaSize[2]:
                        price=12.99
                    elif psize==SelPizzaSize[3]:
                        price=14.99
                elif pizza==Pizzatype[1]:
                    if psize==SelPizzaSize[0]:
                        price=10.99
                    elif psize==SelPizzaSize[1]:
                        price=11.99
                    elif psize==SelPizzaSize[2]:
                        price=13.99
                    elif psize==SelPizzaSize[3]:
                        price=15.99
                elif pizza==Pizzatype[2]:
                    if psize==SelPizzaSize[0]:
                        price=8.99
                    elif psize==SelPizzaSize[1]:
                        price=12.99
                    elif psize==SelPizzaSize[2]:
                        price=14.99
                    elif psize==SelPizzaSize[3]:
                        price=16.99
                elif pizza==Pizzatype[3]:
                    if psize==SelPizzaSize[0]:
                        price=6.99
                    elif psize==SelPizzaSize[1]:
                        price=10.99
                    elif psize==SelPizzaSize[2]:
                        price=12.99
                    elif psize==SelPizzaSize[3]:
                        price=14.99
                elif pizza==Pizzatype[4]:
                    if psize==SelPizzaSize[0]:
                        price=4
                    elif psize==SelPizzaSize[1]:
                        price=6
                    elif psize==SelPizzaSize[2]:
                        price=8
                    elif psize==SelPizzaSize[3]:
                        price=10
                elif pizza==Pizzatype[5]:
                    if psize==SelPizzaSize[0]:
                        price=12.99
                    elif psize==SelPizzaSize[1]:
                        price=14.99
                    elif psize==SelPizzaSize[2]:
                        price=16.99
                    elif psize==SelPizzaSize[3]:
                        price=20.99
            return price

    frame = tkinter.Frame(window)
    frame.pack()
    user_infor_frame = tkinter.LabelFrame(frame, text = "Order Form")
    user_infor_frame.grid(row=0,column=0, sticky="news",padx=20,pady=20)

    f_name_label = tkinter.Label(user_infor_frame,text="Customer Name")
    f_name_label.grid(row=0,column=0)


    entry_name =tkinter.StringVar()
    f_name_entry = tkinter.Entry(user_infor_frame,textvariable=entry_name)
    f_name_entry.grid(row=1,column=0)


    title_label = tkinter.Label(user_infor_frame, text="Menu")
    title_combobox = ttk.Combobox(user_infor_frame,values = PIZZA)

    title_label.grid(row=3, column=0)
    title_combobox.grid(row=4, column=0, padx=30) 

    topping_label = tkinter.Label(user_infor_frame, text="Topping")
    topping_combobox = ttk.Combobox(user_infor_frame,values = PIZZATopping)

    topping_label.grid(row=3, column=1)
    topping_combobox.grid(row=4, column=1, padx=30)


    size_label = tkinter.Label(user_infor_frame, text="Select Size in inches/Pieces")
    size_combobox = ttk.Combobox(user_infor_frame,values = PIZZASIZE)

    size_label.grid(row=3, column=2)
    size_combobox.grid(row=4, column=2, padx=30)

    quantity_label = tkinter.Label(user_infor_frame,text="Quantity")
    quantity_label.grid(row=3,column=3)
    entry_int =tkinter.IntVar()
    quantity_entry = tkinter.Entry(user_infor_frame,textvariable=entry_int)
    quantity_entry.grid(row=4,column=3, padx=30)


    count = 0
    counter = 0
    Pizzaadd = [] 
    Pizzasizeadd = [] 
    Pizzaqntadd = [ ]
    Pizzatoppingadd = [ ]
    del_buttons = [ ]
    
    def add_Pizza():
        global counter
        counter += 1
        global count
        count = counter
        title1_combobox = ttk.Combobox(user_infor_frame,values = PIZZA)
        title1_combobox.grid(row=4+counter, column=0, padx=30)
        size1_combobox=ttk.Combobox(user_infor_frame,values = PIZZASIZE) 
        size1_combobox.grid(row=4+counter, column=2, padx=30)
    
        topping_combobox = ttk.Combobox(user_infor_frame,values = PIZZATopping)
        topping_combobox.grid(row=4+counter, column=1, padx=30)
    
        entry_int_count =tkinter.IntVar()
        quantity1_entry = tkinter.Entry(user_infor_frame,textvariable=entry_int_count)
        quantity1_entry.grid(row=4+counter,column=3, padx=30)

        del_button =Button(user_infor_frame,text = 'Delete',command=lambda:deleteMe(count))
        del_button.grid(row=4+counter,column=4, padx=30)
        del_buttons.append(del_button)

        button.grid(row=16+counter, column=1, padx=30)
    
        Pizzaadd.append(title1_combobox)
        Pizzasizeadd.append(size1_combobox)
        Pizzaqntadd.append(quantity1_entry)
        Pizzatoppingadd.append(topping_combobox)

    def PlaceOrder():

        Total_Price=0
        Pizza=title_combobox.get()
        Pizzasize=size_combobox.get()
        Pizzaqnt=entry_int.get()
        customer_Name=entry_name.get()

        my_price=PriceCal(Pizza,Pizzasize)
        pizza_price = my_price*Pizzaqnt

        Total_Price=Total_Price+ pizza_price

        my_scrollbar = Scrollbar(frame, orient=VERTICAL)

        Lb1 = Listbox(frame,height = 20, 
                      width = 15, 
                      bg = "white",
                      activestyle = 'dotbox', 
                      font = "Helvetica",
                      fg = "black",
                      yscrollcommand=my_scrollbar.set)  

    
        my_scrollbar.config(command=Lb1.yview)
        my_scrollbar.grid(row=40,column=1,rowspan=3, sticky='nsw')
        Lb1.grid(row=40,column=0,rowspan=3, sticky='we')

        button['state']='disabled'

   
        Lb1.insert(END, "==================================")
        Lb1.insert(END, "==================================")
        Lb1.insert(END, "*************Sunshine Pizza******")
        Lb1.insert(END, "Customer Name: "+str(customer_Name))
        Lb1.insert(END, "==================================")
        Lb1.insert(END, "*************Your Order******")
        Lb1.insert(END, "==================================")
        Lb1.insert(END, "Type :"+str(Pizza))
        Lb1.insert(END, "Size: "+str(Pizzasize))
        Lb1.insert(END, "Qauntity: "+str(Pizzaqnt))
        Lb1.insert(END, "Price:-----------------------$"+str("%.2f"%pizza_price))
        Lb1.insert(END, "---------------------------------")
    
        print("Pizza Type",Pizza)
        print("Pizza Size",Pizzasize)
        print("Pizza Qnty",Pizzaqnt)
        print("printing count",count)
        if count != 0:
            for index in range(0,count):
                Pizza=Pizzaadd[index]
                Pizza_add=Pizza.get()

                Pizza_size=Pizzasizeadd[index]
                Psize_add=Pizza_size.get()
                Pizz_aqnt=Pizzaqntadd[index]

                Pizza_aqnt=Pizz_aqnt.get()

                my_price=PriceCal(Pizza_add,Psize_add)

                pizza_price = float(my_price)*int(Pizza_aqnt)

                Total_Price=Total_Price + pizza_price
            

                Lb1.insert(END, "Type : "+str(Pizza_add))
                Lb1.insert(END, "Size: "+str(Psize_add))
                Lb1.insert(END, "Quntity: "+str(Pizza_aqnt))
                Lb1.insert(END, "Price-----------------------$:"+(str(pizza_price)))
                Lb1.insert(END, "----------------------------")
            
                print("Pizza Type",Pizza_add)
                print("Pizza Type",Psize_add)
                print("Pizza quntity",Pizza_aqnt)

        Tax=0.13*Total_Price
        Overall_Total_price=Total_Price+Tax
            
        Lb1.insert(END, "Sub Total -----------------------$"+(str("%.2f"%Total_Price)))
        Lb1.insert(END, "Tax 13%-------------------------$"+(str("%.2f"%Tax)))
        print("============================================")
        Lb1.insert(END, "Total ---------------------------$"+(str("%.2f"%Overall_Total_price)))

        Lb1.insert(END, "--------------------------------------------------")
        Lb1.insert(END, "----------Sunshine Pizza !!!!---------------------")
        Lb1.insert(END, "----------Thank you !!!!--------------------------")


    def myExit():
            window.destroy()
        
    def deleteMe(count):
        for index in range(0,count):
            Pizzaadd[index].destroy()
            Pizzasizeadd[index].destroy()
            Pizzaqntadd[index].destroy()
            Pizzatoppingadd[index].destroy()
            del_buttons[index].destroy()
    
    
    def myNeworder():
            for widget in window.winfo_children():
                    if isinstance(widget,tkinter.Entry):
                            widget.delete(0,'end')
                    if isinstance(widget,ttk.Combobox):
                            widget.delete(0,'end')      
                    if isinstance(widget,ttk.Combobox):
                            widget.delete(0,'end')
            button['state']='active'
            button2['state']='disabled'

    button = ttk.Button(user_infor_frame, text = 'Add More', command = add_Pizza)
    button.grid(row=16, column=0, padx=10)



    button =ttk.Button(frame, text = "Place Order",command = PlaceOrder)
    button.grid(row=32, column=0, padx=10, columnspan=3,sticky="news")

    button2 =ttk.Button(frame, text = "New Order",command = myNeworder)
    button2.grid(row=33, column=0, padx=10, columnspan=3,sticky="news")

    button3 = ttk.Button(frame, text = 'Exit', command = myExit)
    button3.grid(row=34, column=0, padx=10, columnspan=3,sticky="news")


#################################################################################################################

img2 = ImageTk.PhotoImage(Image.open("pizza4.GIF")) ###image=img2
button=Button(root,image=img2,text="Pick and Place Order",command=OrderingForm)
button.pack(expand=True)

button=Button(root, text="EXIT",command=ask_yesornoQ)
button.pack()

root.mainloop()
